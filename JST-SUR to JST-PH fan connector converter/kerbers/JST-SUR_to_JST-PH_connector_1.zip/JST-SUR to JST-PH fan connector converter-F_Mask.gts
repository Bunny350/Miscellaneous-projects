G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-07-20T23:53:39+08:00*
G04 #@! TF.ProjectId,JST-SUR to JST-PH fan connector converter,4a53542d-5355-4522-9074-6f204a53542d,1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-07-20 23:53:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.350000X0.625000X-0.350000X0.625000X-0.350000X-0.625000X0.350000X-0.625000X0*%
%ADD11O,1.200000X1.750000*%
%ADD12RoundRect,0.125000X0.125000X0.425000X-0.125000X0.425000X-0.125000X-0.425000X0.125000X-0.425000X0*%
%ADD13RoundRect,0.250000X0.350000X0.600000X-0.350000X0.600000X-0.350000X-0.600000X0.350000X-0.600000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X148500000Y-84000000D03*
D11*
X146500000Y-84000000D03*
X144500000Y-84000000D03*
X142500000Y-84000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X146700000Y-91750000D03*
X145900000Y-91750000D03*
X145100000Y-91750000D03*
X144300000Y-91750000D03*
D13*
X148000000Y-93150000D03*
X143000000Y-93150000D03*
G04 #@! TD*
M02*
